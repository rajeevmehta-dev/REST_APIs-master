import { Injectable } from '@angular/core';
import { Items } from './items';
import { Observable } from 'rxjs/Observable';
import { RequestOptions, Http, Headers, Response } from '@angular/http';
import { map } from 'rxjs/operators';

@Injectable()
export class ItemsService {
  private dataURL = 'http://localhost:3000/item'
  public url = '';

  constructor(private http: Http) { }

  save(obj: Items): Observable<Items[]> {
    console.log("Save Service Called");

    let headers = new Headers;
    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');

    let options = new RequestOptions({ headers: headers });

    return this.http.post(this.dataURL + '/items', { 'data': obj }, options).pipe(map((res: Response) => res.json()));

  }
  update(obj: Items): Observable<Items[]> {
    console.log("Update Service Called");

    let headers = new Headers;
    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');

    let options = new RequestOptions({ headers: headers });

    return this.http.put(this.dataURL + '/items', { 'data': obj }, options).pipe(map((res: Response) => res.json()));

  }
  get_black(filter: string[], obj1: Items, range: any[], sort: any)
    : Observable<Items[]> {
    console.log("Get Black Service Called");
    console.log(filter);

    this.make_url(obj1, range, sort, filter);
    return this.http.get(this.url)
      .pipe(map((res: Response) => res.json()));

  }

  price_range(range: string[], obj1: Items, filter: any[], sort: any)
    : Observable<Items[]> {
    console.log("Price Range Service Called");
    console.log("Filter");
    console.log(filter);
    console.log("Sort");
    console.log(sort);


    this.make_url(obj1, range, sort, filter);
    console.log(this.url);
    return this.http.get(this.url)
      .pipe(map((res: Response) => res.json()));

  }

  delete(_id: String, obj: Items): Observable<any[]> {
    console.log("Delete Service Called");
    console.log(obj);

    let headers = new Headers;
    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');

    let options = new RequestOptions({ headers: headers });
    let url = this.dataURL + '/items/' + _id + '?&id=' + obj.user_id + '&token=' + obj.token;
    console.log(url);

    return this.http.post(url, options).pipe(map((res: Response) => res.json()));


  }
  loadData(obj: Items): Observable<Items[]> {
    console.log("loadData Service Called");

    let url = this.dataURL + '/items?id=' + obj.user_id + '&token=' + obj.token;
    console.log(url);
    return this.http.get(url)
      .pipe(map((res: Response) => res.json()));

  }
  sort(sort: any, obj1: Items, range: any[], filter: any[]): Observable<Items[]> {
    console.log("Sort Service Called");

    this.make_url(obj1, range, sort, filter);
    return this.http.get(this.url)
      .pipe(map((res: Response) => res.json()));

  }



  make_url(obj1: Items, range: any[], sort: any, filter: any[]) {

    if (filter.length !== 0 && sort == null && range.length == 0) {
      console.log("ONLY FILTER");
      this.url = this.dataURL + '/items?&id=' + obj1.user_id + '&token=' + obj1.token +
        '&filter=' + JSON.stringify(filter);
    }
    else if (sort !== null && filter.length !== 0 && range.length == 0) {
      console.log("FILTER AND SORT");
      this.url = this.dataURL + '/items?&id=' + obj1.user_id + '&token=' + obj1.token +
        '&filter=' + JSON.stringify(filter) + '&sort=' + JSON.stringify(sort);

    }
    else if (sort !== null && filter.length == 0 && range.length == 0) {
      console.log("ONLY SORT");
      this.url = this.dataURL + '/items?&&id=' + obj1.user_id + '&token=' + obj1.token
        + '&sort=' + JSON.stringify(sort);
    }
    else if (sort == null && filter.length == 0 && range.length !== 0) {
      console.log("RANGE ONLY");
      this.url = this.dataURL + '/items?&range=' + JSON.stringify(range) + '&id=' + obj1.user_id + '&token=' + obj1.token;
    }
    else if (sort != null && filter.length !== 0 && range.length !== 0) {
      console.log("SORT,RANGE AND FILTER");
      this.url = this.dataURL + '/items?&range=' + JSON.stringify(range) + '&id=' + obj1.user_id + '&token=' + obj1.token
        + '&filter=' + JSON.stringify(filter) + '&sort=' + JSON.stringify(sort);
    }
    else if (filter.length !== 0 && range.length !== 0 && sort == null) {
      console.log("FILTER AND RANGE")
      this.url = this.dataURL + '/items?&range=' + JSON.stringify(range) + '&id=' + obj1.user_id + '&token=' + obj1.token
        + '&filter=' + JSON.stringify(filter);
    }
    else if (sort !== null && range.length !== 0) {
      console.log("SORT AND RANGE");
      this.url = this.dataURL + '/items?&range=' + JSON.stringify(range) + '&id=' + obj1.user_id + '&token=' + obj1.token
        + '&sort=' + JSON.stringify(sort);
    }


  }
}
