export class Items {
    name:String;
    price:Number;
    category:String;
    color:String;
    _id:String;
    token:String;
    user_id:String;
}
