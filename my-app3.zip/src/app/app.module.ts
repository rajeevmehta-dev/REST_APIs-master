import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { HeaderComponent } from './header/header.component';
import { RegisterService } from './register.service';
import { ItemsComponent } from './items/items.component';
import { ItemsService } from './items.service';

const appRoutes = [
  { path: 'register', component: RegisterComponent },
  { path: 'items', component: ItemsComponent },
  
]

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    HeaderComponent,
    ItemsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule, ReactiveFormsModule,
    HttpModule, RouterModule.forRoot(appRoutes)
  ],
  providers: [RegisterService,ItemsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
