import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { RegisterService } from 'app/register.service';
import { Register } from 'app/register';
import { Login } from 'app/register';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  public reg: Register;
  public regs: String[];
  public log: Login;
  public usernm: String;
  
  constructor(private dataservice: RegisterService, private ref: ChangeDetectorRef) {
    this.reg = new Register();
    this.regs = [];
    this.log = new Login();

  }

  ngOnInit() {
    // this.loadData();
    this.usernm = localStorage.getItem('Username');
    console.log(this.usernm);
  }
  save() {
    console.log("Save Clicked");
    this.dataservice.save(this.reg).subscribe((data) => {

      console.log(data);
      this.ref.detectChanges();

      this.clear();
    });
  }

  edit(val) {
    this.reg.username = val.username;
    this.reg.email = val.email;
    this.reg.password = val.password;
    this.reg._id = val._id;
  }



  clear() {
    this.reg.username = '';
    this.reg.email = '';
    this.reg.password = '';
  }


  login() {

    this.dataservice.login(this.log).subscribe((data) => {


      if (data.success == true) {
        console.log("Login Successful");

        localStorage.setItem('token', data.token);
        localStorage.setItem('Username', data.username);
        localStorage.setItem('id', data._id);
        console.log(data.token);
        this.update_token();
        this.usernm = data.username;


      }
      else if (data.success == false) {

        console.log(data.message);
      }
      else if (data.error == false) {

        console.log(data.message);
      }
    });
    this.log.email = "";
    this.log.password = "";

  }
  update_token() {
    this.reg.token = localStorage.getItem('token');
    this.reg._id = localStorage.getItem('id');
    if (this.reg.token == undefined || this.reg.token == '') {
      this.reg.token = '';
    }
    this.dataservice.update_token(this.reg).subscribe((data) => {
      console.log(data);
      this.ref.detectChanges();
    });
  }
  signout() {
    localStorage.removeItem('token');
    localStorage.removeItem('Username');
    this.update_token();
    localStorage.removeItem('id');
   
   
    this.usernm = null;
    console.log('username now:' + this.usernm);
    console.log('Id now:' + localStorage.getItem('id'));
    console.log("Logged Out");
    
  }
}
