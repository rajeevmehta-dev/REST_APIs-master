import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers, Response } from '@angular/http';
import { Register, Login } from './register';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';

@Injectable()
export class RegisterService {

  private dataURL = "http://localhost:3000/register";
  constructor(private http: Http) { }

  save(obj: Register): Observable<Register[]> {
    console.log("Save Service Called");

    let headers = new Headers;
    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');

    let options = new RequestOptions({ headers: headers });

    return this.http.post(this.dataURL + '/register', { 'data': obj }, options).pipe(map((res: Response) => res.json()));


  }


  login(obj: Login): Observable<any> {
    console.log('Login service called');
    let headers = new Headers();

    headers.append('Accept', 'application/json')
    let options = new RequestOptions({ headers: headers });
    return this.http.post(this.dataURL + '/login', obj
      , options)
      .pipe(map((res: Response) => res.json()));
  }

  signout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('Username');
    localStorage.removeItem('id');
  }
  update_token(obj: Register) {
    console.log("Update Token Service Called");

    let headers = new Headers;
    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');

    let options = new RequestOptions({ headers: headers });

    return this.http.put(this.dataURL + '/update_token', { 'data': obj }, options).pipe(map((res: Response) => res.json()));

  }

 

}
