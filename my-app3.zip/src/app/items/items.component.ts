import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Items } from 'app/items';
import { ItemsService } from 'app/items.service';

@Component({
  selector: 'app-items',
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.css']
})
export class ItemsComponent implements OnInit {
  public itm: Items;
  public itmarr: Items[];
  public filter: any[];
  public sort: any;
  public lt:number;
  public gt:number;
  public range: any[];

  constructor(private ref: ChangeDetectorRef, private dataservice: ItemsService) {
    this.itm = new Items();
    this.itmarr = [];
    this.filter = [];
    this.range=[];


  }

  ngOnInit() {
    this.loadData();
  }
  sort_price() {
    this.itm.token = localStorage.getItem('token');
    this.itm.user_id = localStorage.getItem('id');
    console.log('sort L to H called');
    this.sort = { 'price': 1 };
    this.dataservice.sort(this.sort,this.itm,this.range,this.filter).subscribe((data) => {

      this.itmarr = data;
    });
  }
  // {"price":{"$gt":50000}},{"price":{"$lt":75000}}
  price_range(){
    this.itm.token = localStorage.getItem('token');
    this.itm.user_id = localStorage.getItem('id');
    this.range=[];
    console.log(this.range);
    if(!this.lt){
      this.range.push({ "price": {"$gt":this.gt}});
    }
    else if(!this.gt){
      this.range.push({ "price": {"$lt":this.lt}});
    }
    else{
      this.range.push({ "price": {"$gt":this.gt}});
      this.range.push({ "price": {"$lt":this.lt}});

    }
    
    this.dataservice.price_range(this.range,this.itm,this.filter,this.sort)
    .subscribe((data)=>{
      this.itmarr=data;
      this.lt=null;
      this.gt=null;
      this.ref.detectChanges();
      
    });
  }
  get_black() {
    this.itm.token = localStorage.getItem('token');
    this.itm.user_id = localStorage.getItem('id');
    this.filter.push({ 'color': 'Black'});
    // this.filter.push({ 'category': 'Mobiles'});
    console.log('this.filter');
    console.log(this.filter);
    this.dataservice.get_black(this.filter,this.itm,this.range,this.sort)
    .subscribe((data)=>{
      this.itmarr=data;
      this.ref.detectChanges();
      
    });
      }
  sort_price1() {
    this.itm.token = localStorage.getItem('token');
    this.itm.user_id = localStorage.getItem('id');
    console.log('sort H to L called');
    this.sort = { 'price': -1 };
    this.dataservice.sort(this.sort,this.itm,this.range,this.filter).subscribe((data) => {

      this.itmarr = data;
    });
  }
  save() {
    this.itm.token = localStorage.getItem('token');
    this.itm.user_id = localStorage.getItem('id');
    console.log("Save Clicked");
    this.dataservice.save(this.itm).subscribe((data) => {

      console.log(data);
      this.ref.detectChanges();
      this.loadData();
      this.clear();
    });
  }
  clear_load(){
    this.sort=null;
    this.filter=[];
    this.range=[];
    this.loadData();
  }

  loadData() {
    
    this.itm.token = localStorage.getItem('token');
    this.itm.user_id = localStorage.getItem('id');
    console.log("Load Data Function Called");
    this.dataservice.loadData(this.itm).subscribe((data) => {
      this.itmarr = data;
      console.log(this.itmarr);
      this.ref.detectChanges();


    });
  }
  edit(val) {
    this.itm.name = val.name;
    this.itm.price = val.price;
    this.itm.category = val.category;
    this.itm.color = val.color;
    this.itm._id = val._id;
  }
  update() {
    this.itm.token = localStorage.getItem('token');
    this.itm.user_id = localStorage.getItem('id');
    this.dataservice.update(this.itm).subscribe((data) => {

      console.log(data);
      this.loadData();
      this.clear();
      this.ref.detectChanges();

    });


  }

  clear() {
    this.itm.name = '';
    this.itm.price = null;
    this.itm.category = '';
    this.itm.color = '';
  }
  delete(val) {
    this.itm.token = localStorage.getItem('token');
    this.itm.user_id = localStorage.getItem('id');
    this.dataservice.delete(val._id, this.itm).subscribe((data) => {

      console.log(data);
      this.ref.detectChanges();
      this.loadData();
    });
  }







}
