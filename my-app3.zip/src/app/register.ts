export class Register {
    username: String;
    email: String;
    password: String;
    _id: String;
    token: String;
}
export class Login {
    email: String;
    password: String;
}