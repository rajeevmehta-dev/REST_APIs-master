module.exports = {
    TOKEN_SECRET: process.env.TOKEN_SECRET || "ABCDEFGH123456"
}
