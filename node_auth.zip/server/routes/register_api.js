
var auth = require('../auth/auth.js');
var express = require('express');
var router = express.Router();
var local = require('../models/register.js');
var app = express();
var cors = require('cors')

app.options('*', cors());


router.post('/register', function (req, res) {
    console.log("req Data here______");
    console.log(req.body.data);
    local.findOne({ username: req.body.username }, function (err, existinguser) {
        if (existinguser) {
            return res.status(409).send({ message: 'Username already exists' });
        }
        var query = new local({
            username: req.body.data.username,

            email: req.body.data.email,

            password: req.body.data.password,

        });

        query.save(function (err, result) {
            if (err) {
                res.send({ message: err.message });
            }
            res.status(200).send({ success: true, token: auth.createJWT(result) });
            console.log("result_______");
            console.log(result);
        })
    });
});

router.post('/login', function (req, res) {
    console.log("login API called_______");
    console.log(req.body);
    local.findOne({ email: req.body.email }, '+password', function (err, user) {
        if (!user) {
            return res.status(401).json({ error: false, message: "Email is incorrect" });
        }
        user.comparepassword(req.body.password, function (err, isMatch) {

            if (!isMatch) {
                return res.status(401).json({ success: false, message: "Wrong password" });
            }
            res.status(200).json({ success: true, token: auth.createJWT(user), username: user.username, _id: user._id });

            console.log(auth.createJWT(user));
        });


    });

});


router.put('/update_token', function (req, res) {
    console.log("Token API called_______");
    console.log(req.body);
    local.findOne({ _id: req.body.data._id }, function (err, user) {
        if (!user) {
            return res.status(404).json({ error: false, message: "User Not Found" });
        }
       user.token=req.body.data.token;

       user.save(function (err, result1) {
        console.log('Executing Update Token Query');

        if (err) res.status(500).send(err);

        return res.status(200).send(result1);
    });
        });


    });

module.exports = router;