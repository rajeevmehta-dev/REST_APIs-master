var express = require('express');
var router = express.Router();
var local = require('../models/items.js');
var register = require('../models/register.js');


router.post('/items', function (req, res) {

    console.log(req.body.data);
    register.findOne({ $and: [{ _id: req.body.data.user_id }, { token: req.body.data.token }] }, function (err, result) {
        if (err)
            res.status(500).send(err);
        if (!result) {
            return res.status(403).send({ message: 'Token Not Applicable' });
        }

        console.log('Save Api for Items Called');
        console.log(req.body.data);

        var data = new local({
            name: req.body.data.name,
            category: req.body.data.category,
            price: req.body.data.price,
            color: req.body.data.color
        });

        data.save(function (err, result) {
            console.log('Executing Save Query');

            if (err) res.status(500).send(err);

            return res.status(200).send(result);
        });

    });
});

router.get('/items', function (req, res) {


    /*
    Query params comes in the form of JSON, and are parsed here into JavaScript Object.
    Filter is in the form of JSON Array, which is ofcourse parsed here.

    */
    console.log("Get Data API for Items Called");
    console.log('req.query is:');
    console.log(req.query);

    if (req.query.token && req.query.id) {
        register.findOne({ $and: [{ _id: req.query.id }, { token: req.query.token }] }, function (err, result) {
            if (err)
                res.status(500).send(err);
            if (!result) {
                return res.status(403).send({ message: 'Token Not Applicable' });
            }

            if (req.query.filter) {

                var filters = JSON.parse(req.query.filter);


            }
            if (req.query.range) {
                let range_str = req.query.range;
                var range1 = range_str.substr(1, range_str.length - 2);
                range1 = JSON.parse(range1);    //Range without [],to be used with FILTER AND RANGE
                var range = JSON.parse(req.query.range);
                console.log("range is:")
                console.log(range);
            }


            let pageNumber = req.query.page;
            let limit = req.query.limit;
            var query;
            if (req.query.sort) {
                var sort = JSON.parse(req.query.sort);
            }
            var page = (pageNumber > 0 ? ((pageNumber - 1) * limit) : 0);


            if (!filters && !sort && !range) {
                console.log('Filter: NO, Sort: NO, Get All');
                query = local.find({}).skip(page).limit(limit);
            }
            else if (filters && sort && !range) {
                console.log('Filter: Yes, Sort: Yes, Range: No');

                query = local.find({ $and: filters }).sort(sort).skip(page).limit(limit);
            }
            else if (!filters && sort && !range) {
                console.log("Sort: YES, Filter: NO, Range:NO");
                console.log(sort);
                query = local.find({}).sort(sort).skip(page).limit(limit);
            }
            else if (filters && !sort && !range) {
                console.log("Sort: NO, Filter: Yes,Range: No");
                console.log(filters);
                query = local.find({ $and: filters }).skip(page).limit(limit);

            }
            else if (!filters && range && !sort) {
                console.log("No Filter, No Sort, Range: Yes")
                query = local.find({ $and: range }).skip(page).limit(limit);
            }
            else if (filters && range && !sort) {
                console.log("Filter: YES, Range: Yes, Sort: No")
                filters_str = req.query.filter;
                filters1 = filters_str.substr(1, filters_str.length - 2);
                filters1 = JSON.parse(filters1);  //FILTER without [],to be used with FILTER AND RANGE
                console.log(filters1);

                /*
                FORMAT FOR USING AND:
                find({ $and: [{"color":"Black"} ,  { price: { '$gt': 55000 } } ]});  */

                query = local.find({ $and: [filters1, range1] }).skip(page).limit(limit);
            }
            else if (range && sort && !filters) {

                console.log("Sort: YES, Filter: NO, Range:Yes");
                console.log(sort);
                query = local.find({ $and: range }).sort(sort).skip(page).limit(limit);
            }
            else if (sort && filters && range) {
                console.log("Sort: YES, Filter: YES, Range:Yes");
                filters_str = req.query.filter;
                filters1 = filters_str.substr(1, filters_str.length - 2);
                filters1 = JSON.parse(filters1);//FILTER without [],to be used with FILTER AND RANGE
                console.log(filters1);

                query = local.find({ $and: [filters1, range1] }).sort(sort).skip(page).limit(limit);
            }



            query.exec(function (err, docs) {
                // if (err) res.status(500).send({ error:err});
                // console.log(query);
                if (!docs) {
                    return res.send(404, 'No data was found');
                }
                console.log("Here are Docs_____")
                console.log(docs);
                return res.status(200).send(JSON.stringify(docs));
            });
        });
    }
    else {
        return res.status(400).send({ message: 'Something is not right' });
    }

});

router.put('/items', function (req, res) {
    console.log('Update Api for Items Called');
    console.log(req.body);


    register.findOne({ $and: [{ _id: req.body.data.user_id }, { token: req.body.data.token }] }, function (err, result) {
        if (err)
            res.status(500).send(err);
        if (!result) {
            return res.status(403).send({ message: 'Token Not Applicable' });
        }

        if (req.body.data == undefined || req.body.data == null) {
            return res.status(400).send('No Body received');
        }
        local.findById(req.body.data._id, function (err, result) {
            if (err)
                res.status(500).send(err);
            if (!result) {
                return res.status(404).send('record not found');
            }

            if (req.body.data.name) { result.name = req.body.data.name }
            if (req.body.data.price) { result.price = req.body.data.price }
            if (req.body.data.category) { result.category = req.body.data.category }
            if (req.body.data.color) { result.color = req.body.data.color }

            result.save(function (err, result1) {
                console.log('Executing Update Query');

                if (err) res.status(500).send(err);

                return res.status(200).send(result1);
            });
        });
    });

});

router.patch('/items/:id', function (req, res) {

    console.log("Patch Update for Items Called");
    if (req.query.token && req.query.id) {
        register.findOne({ $and: [{ _id: req.query.id }, { token: req.query.token }] }, function (err, result) {
            if (err)
                res.status(500).send(err);
            if (!result) {
                return res.status(403).send({ message: 'Token Not Applicable' });
            }
            let updateObject = req.body;
            let id = req.params.id;

            local.findById({ _id: req.params.id }, function (err, result) {
                if (err) throw err;
                if (!result) {
                    res.status(404).send('No record found to update');
                }
                else {
                    let query = local.updateOne({ _id: id }, { $set: updateObject });
                    query.exec(function (err, result) {

                        if (err) throw err;
                        res.status(200).send(result);
                    });
                }
            });
        });
    }
    else {
        return res.status(400).send({ message: 'Something is not right' });
    }

});
router.post('/items/:id', function (req, res) {

    console.log('Delete Api for Items Called');
    console.log(req.query);
    if (req.query.token && req.query.id) {
        register.findOne({ $and: [{ _id: req.query.id }, { token: req.query.token }] }, function (err, result) {
            if (err)
                res.status(500).send(err);
            if (!result) {
                return res.status(403).send({ message: 'Token Not Applicable' });
            }


            local.deleteOne({ _id: req.params.id }, function (err, result) {

                if (err) console.log(err);
                res.status(200).send({ success: true });
            });
        });
    }
    else {
        return res.status(400).send({ message: 'Something is not right' });
    }

});

module.exports = router;