var mongoose = require('mongoose');
var Schema = mongoose.Schema;


var userschema = new Schema({
    name: String,
    category: String,
    color:String,
    price:Number
    
}, { versionKey: false });

module.exports = mongoose.model('items', userschema);